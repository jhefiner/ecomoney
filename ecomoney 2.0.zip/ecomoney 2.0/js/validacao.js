acu = true;

/*
 * Veja a documentação em:
 * https://getbootstrap.com/docs/4.0/components/carousel/#events
 */
$('#carouselExampleIndicators').on('slid.bs.carousel', function(event) {
    let img = event.relatedTarget.querySelector('img');
    $('#image-name').text(img.src);
    $('#perfil_foto').val(img.src);
});

//$('#meucarrossel').carousel({
    //interval: false
//});
