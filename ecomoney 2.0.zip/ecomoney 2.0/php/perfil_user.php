<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoMoney - Economia Sustentável</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/paginas.css" />
    <link rel="stylesheet" href="../css/cover.css" />
    <link rel="icon" type="favicon/png" href="../img/favicon.png"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body class="text-center">
    <div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
        <?php
            include "../inc/cabecalho_conexao.inc";

            $id_usuario = $_SESSION['id'];

            $SQL = "SELECT `id_perfil` FROM `perfil` WHERE id_perfil = $id_usuario";

            $dados_recuperados = mysqli_query($con, $SQL);

            if(mysqli_num_rows($dados_recuperados) > 0){
                while( ($resultado = mysqli_fetch_array($dados_recuperados)) != null) {
                    include "../inc/menu_user.inc";
                    include "../inc/perfil_pronto.php";            
                }
                include "../inc/modal_questionario.php"; 
            }else{
                include "../inc/menu_user_sem_bot.inc";
                include "../inc/perfil.inc";
            }
            include "../inc/rodape_conexao.inc";
            include "../inc/rodape.inc";
        ?>
    </div>
<?php
    include "../inc/fim_html.inc";
?>