<?php
    session_start();
    $id_perfil = $_SESSION['id'];
    $nome = $_SESSION['nome'];
    $data_nascimento = $_SESSION['data_nascimento'];
    $foto = $_POST["perfil_foto"];
    
    //$_SESSION['perfil_foto'] = $foto;

    //Abrindo conexão com o BD
    include "../inc/cabecalho_conexao.inc";

        $SQL = "INSERT INTO `perfil` (`id_perfil`, `nome`, `data_nascimento`, `foto`) 
                VALUES ($id_perfil, '$nome', '$data_nascimento', '$foto')";

    include "../inc/rodape_conexao.inc";
    header ("Location:perfil_user.php");
?>