<?php
    $nome = $_POST['nome'];
    $data_nascimento = $_POST['data_nascimento'];
    $cad_email = $_POST['cad_email'];
    $senha = $_POST['senha'];
    $conf_senha = $_POST['senha'];
    //Abrindo conexão com o BD
    include "../inc/cabecalho_conexao.inc";

        $SQL = "INSERT INTO `usuarios` (`nome`, `data_nascimento`, `email`, `senha`, `confirmacao_senha`) 
                VALUES ('$nome', '$data_nascimento', '$cad_email', '$senha', '$conf_senha')";

    include "../inc/rodape_conexao.inc";
    header ("Location:../index.php");
?>