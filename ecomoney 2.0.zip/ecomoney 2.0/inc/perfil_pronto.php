<main role="main" class="inner cover">
    <div class="container">
        <div class="row">
            <div class="col">
                <img src="<?php

                $id_usuario = $_SESSION['id'];
                include "../inc/cabecalho_conexao.inc";

                $SQL = "SELECT `foto` FROM `perfil` WHERE id_perfil = $id_usuario";

                $dados_recuperados = mysqli_query($con, $SQL);

                if(mysqli_num_rows($dados_recuperados) > 0){
                    while( ($resultado = mysqli_fetch_array($dados_recuperados)) != null) {
                        $_SESSION['perfil_foto'] = $resultado[0];           
                    }
                }
                include "../inc/rodape_conexao.inc";
                echo $_SESSION['perfil_foto'];
                
                ?>" class="img rounded mx-auto d-block" ></img>
            </div>
            <div class="col">
                <div class="card card text-white mb-3 border border-success" style="max-width: 25rem; background-color:#333;">
                    <div class="card-header border-success">
                        <h5 class="card-title">Questionário</h5>
                    </div>
                    <div class="card-body">
                        <p class="card-text">Responda as perguntas para saber quão sustentável você é.</p>
                        <button type="button" class="btn btn-success bot" data-toggle="modal" data-target=".bd-example-modal-lg">Inicie aqui</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="card card text-white mb-3 border border-success" style="max-width: 25rem; background-color:#333;">
                    <div class="card-header border-success">
                        <h5 class="card-title">Bio</h5>
                    </div>
                    <div class="card-body">
                        <?php
                            echo '<b>Nome: </b>'.$_SESSION['nome'].'';
                        ?>
                    </div>
                </div>            
            </div>
            <div class="col">
                <div class="card card text-white mb-3 border border-success" style="max-width: 25rem; background-color:#333;">
                    <div class="card-header border-success">
                        <h5 class="card-title">Ranking</h5>
                    </div>
                    <div class="card-body">
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>